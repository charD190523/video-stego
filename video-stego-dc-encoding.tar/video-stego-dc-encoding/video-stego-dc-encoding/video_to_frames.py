import cv2
import os
from moviepy.editor import VideoFileClip, AudioFileClip

def frames_to_video():
    # Đọc frame đầu tiên để lấy kích thước
    img = cv2.imread("frames/frame0.png")
    if img is None:
        print("Error: No frames found in frames/ directory!")
        return
    height, width, layers = img.shape
    size = (width, height)
    
    fps = 30  # Giả định FPS cố định, có thể điều chỉnh dựa trên video gốc
    frame_list = [f for f in os.listdir("frames/") if f.endswith(".png")]
    frame_list.sort(key=lambda x: int(x.replace("frame", "").replace(".png", "")))
    
    # Tạo video tạm với nén tối ưu (CRF 23, chất lượng tốt với kích thước hợp lý)
    out = cv2.VideoWriter('temp_video.mp4', cv2.VideoWriter_fourcc(*'X264'), fps, size)
    
    for frame in frame_list:
        img_path = os.path.join("frames/", frame)
        img = cv2.imread(img_path)
        out.write(img)
    
    out.release()
    
    # Thêm âm thanh vào video với tham số nén
    if os.path.exists("video/output.mp3"):
        video = VideoFileClip("temp_video.mp4")
        audio = AudioFileClip("video/output.mp3")
        final_video = video.set_audio(audio)
        final_video.write_videofile("video/final.mp4", codec='libx264', audio_codec='aac', ffmpeg_params=['-crf', '23'])
        video.close()
        audio.close()
        os.remove("temp_video.mp4")
    else:
        os.rename("temp_video.mp4", "video/final.mp4")
    
    print("Video encoded successfully!")
