#!/usr/bin/env python3
import os
import cv2
import sys
import math
import numpy as np
import itertools
import matplotlib.pyplot as plt
from PIL import Image
from pathlib import Path

from frames_to_video import frames_to_video

quant = np.array([[16, 11, 10, 16, 24, 40, 51, 61],      # QUANTIZATION TABLE
                  [12, 12, 14, 19, 26, 58, 60, 55],    # required for DCT
                  [14, 13, 16, 24, 40, 57, 69, 56],
                  [14, 17, 22, 29, 51, 87, 80, 62],
                  [18, 22, 37, 56, 68, 109, 103, 77],
                  [24, 35, 55, 64, 81, 104, 113, 92],
                  [49, 64, 78, 87, 103, 121, 120, 101],
                  [72, 92, 95, 98, 112, 100, 103, 99]])

class DCT():
    def __init__(self):  # Constructor
        self.message = None
        self.bitMess = None
        self.oriCol = 0
        self.oriRow = 0

    def encode_image(self, img, secret_msg):
        secret = secret_msg
        self.message = str(len(secret))+'*'+secret
        self.bitMess = self.toBits()

        # get size of image in pixels
        row, col = img.shape[:2]

        self.oriRow, self.oriCol = row, col

        # make divisible by 8x8
        if row % 8 != 0 or col % 8 != 0:
            img = self.addPadd(img, row, col)

        row, col = img.shape[:2]

        # split image into RGB channels
        bImg, gImg, rImg = cv2.split(img)

        # message to be hid in blue channel so converted to type float32 for dct function
        bImg = np.float32(bImg)

        # break into 8x8 blocks
        imgBlocks = [np.round(bImg[j:j+8, i:i+8]-128) for (j, i) in itertools.product(range(0, row, 8),
                                                                                      range(0, col, 8))]

        # Blocks are run through DCT function
        dctBlocks = [np.round(cv2.dct(img_Block)) for img_Block in imgBlocks]

        # blocks then run through quantization table
        quantizedDCT = [np.round(dct_Block/quant) for dct_Block in dctBlocks]

        # set LSB in DC value corresponding bit of message
        messIndex = 0
        letterIndex = 0
        for quantizedBlock in quantizedDCT:
            # find LSB in DC coeff and replace with message bit
            DC = quantizedBlock[0][0]  # Using DC coefficient
            DC = np.uint8(DC)
            DC = np.unpackbits(DC)
            DC[7] = self.bitMess[messIndex][letterIndex]
            DC = np.packbits(DC)
            DC = np.float32(DC)
            DC = DC-255
            quantizedBlock[0][0] = DC
            letterIndex = letterIndex+1
            if letterIndex == 8:
                letterIndex = 0
                messIndex = messIndex + 1
                if messIndex == len(self.message):
                    break

        # blocks run inversely through quantization table
        sImgBlocks = [quantizedBlock * quant +
                      128 for quantizedBlock in quantizedDCT]

        # puts the new image back together
        sImg = []
        for chunkRowBlocks in self.chunks(sImgBlocks, col/8):
            for rowBlockNum in range(8):
                for block in chunkRowBlocks:
                    sImg.extend(block[rowBlockNum])
        sImg = np.array(sImg).reshape(row, col)

        # converted from type float32
        sImg = np.uint8(sImg)
        sImg = cv2.merge((sImg, gImg, rImg))
        return sImg

    def addPadd(self, img, row, col):
        # add padding to make image divisible by 8x8
        rowPad = 8 - (row % 8) if row % 8 != 0 else 0
        colPad = 8 - (col % 8) if col % 8 != 0 else 0
        padded_img = np.pad(img, ((0, rowPad), (0, colPad), (0, 0)), mode='constant')
        return padded_img

    def chunks(self, l, n):
        m = int(n)
        for i in range(0, len(l), m):
            yield l[i:i + m]

    def toBits(self):
        bits = []
        for char in self.message:
            binval = bin(ord(char))[2:].rjust(8, '0')
            bits.append(binval)
        return bits

def calculate_capacity(frame_path):
    """
    Tính số bit tối đa có thể nhúng dựa trên một frame duy nhất.
    Args:
        frame_path (str): Đường dẫn đến frame cần tính (frame10.png).
    Returns:
        int: Số bit tối đa có thể nhúng.
    """
    img = cv2.imread(frame_path)
    if img is None:
        raise ValueError(f"Error: Could not read {frame_path} to calculate capacity!")
    
    height, width = img.shape[:2]
    
    # Số khối 8x8 trong frame
    blocks_per_frame = (width // 8) * (height // 8)
    
    # Tổng số bit tối đa (1 bit trên mỗi khối)
    total_capacity_bits = blocks_per_frame
    return total_capacity_bits

def main_encode():
    # Nhập đường dẫn đến file chứa thông điệp bí mật
    secret_msg_file = input("Enter the path to the file containing the secret message: ")
    if not os.path.isfile(secret_msg_file):
        print("Error: Secret message file not found!")
        return

    # Đọc nội dung thông điệp từ file
    try:
        with open(secret_msg_file, 'r') as f:
            secret_msg = f.read().strip()
    except Exception as e:
        print(f"Error reading secret message file: {e}")
        return

    if not secret_msg:
        print("Error: Secret message cannot be empty!")
        return

    # Đảm bảo thư mục frames tồn tại
    frames_dir = "frames/"
    if not os.path.exists(frames_dir):
        print("Error: Frames directory not found! Please run extract_frames.py first.")
        return

    # Đường dẫn đến frame10.png
    frame_path = os.path.join(frames_dir, "frame10.png")
    if not os.path.isfile(frame_path):
        print("Error: Image frame10.png not found! Ensure frames were extracted correctly.")
        return

    # Tính giới hạn giấu tin cho một frame duy nhất
    try:
        total_capacity_bits = calculate_capacity(frame_path)
    except Exception as e:
        print(f"Error calculating capacity: {e}")
        return

    # Tính số bit cần nhúng
    full_message = str(len(secret_msg)) + '*' + secret_msg
    total_bits_needed = len(full_message) * 8

    # Kiểm tra giới hạn giấu tin
    if total_bits_needed > total_capacity_bits:
        max_chars = (total_capacity_bits // 8) - (len(str(total_capacity_bits // 8)) + 1)
        print(f"Error: Message too large to encode in a single frame! Maximum capacity is {max_chars} characters, but message requires {len(secret_msg)} characters.")
        return

    # Change dir to frames
    os.chdir("frames/")

    # Choose frame to encode
    img_name = "frame10.png"
    print("Chose frame10.png to encode")

    img = cv2.imread(img_name, cv2.IMREAD_UNCHANGED)
    # Mã hóa thông điệp vào image
    encoded_img = DCT().encode_image(img, secret_msg)
    if encoded_img is False:  # If encoding failed (e.g., message too large)
        os.chdir("..")
        return

    cv2.imwrite(img_name, encoded_img)
    os.chdir("..")

    # Build encoded video
    print("Building encoded video...")
    frames_to_video()

    # Hiển thị thông tin
    print("Secret Message is: " + str(secret_msg))
    print("Secret Message Length is: " + str(len(secret_msg)))
    print("final.mp4 is saved in Folder video")
    print("Encoding Successfully!!!")

if __name__ == "__main__":
    main_encode()
