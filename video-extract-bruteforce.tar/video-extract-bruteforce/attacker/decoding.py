#!/usr/bin/env python3
import os
import cv2
import sys
import numpy as np
import itertools
from os import listdir
from os.path import join

quant = np.array([[16, 11, 10, 16, 24, 40, 51, 61],
                  [12, 12, 14, 19, 26, 58, 60, 55],
                  [14, 13, 16, 24, 40, 57, 69, 56],
                  [14, 17, 22, 29, 51, 87, 80, 62],
                  [18, 22, 37, 56, 68, 109, 103, 77],
                  [24, 35, 55, 64, 81, 104, 113, 92],
                  [49, 64, 78, 87, 103, 121, 120, 101],
                  [72, 92, 95, 98, 112, 100, 103, 99]])

class DCT():
    def decode_image(self, img):
        row, col = img.shape[:2]
        messSize = None
        messageBits = []
        buff = 0

        bImg, gImg, rImg = cv2.split(img)
        bImg = np.float32(bImg)

        imgBlocks = [bImg[j:j+8, i:i+8] - 128 for (j, i) in itertools.product(range(0, row, 8), range(0, col, 8))]
        quantizedDCT = [img_Block / quant for img_Block in imgBlocks]

        i = 0
        for quantizedBlock in quantizedDCT:
            DC = quantizedBlock[0][0]
            DC = np.uint8(DC)
            DC = np.unpackbits(DC)
            if DC[7] == 1:
                buff += (0 & 1) << (7 - i)
            elif DC[7] == 0:
                buff += (1 & 1) << (7 - i)

            i = 1 + i
            if i == 8:
                messageBits.append(chr(buff))
                buff = 0
                i = 0
                if messageBits[-1] == '*' and messSize is None:
                    try:
                        messSize = int(''.join(messageBits[:-1]))
                        print(f'--> Length Message: {messSize}')
                    except:
                        pass
            if len(messageBits) - len(str(messSize)) - 1 == messSize and messSize is not None:
                return ''.join(messageBits)[len(str(messSize)) + 1:]
        return ''

def scan_frames_for_message(frames_dir):
    files = [f for f in listdir(frames_dir) if f.endswith('.png')]
    files.sort(key=lambda x: int(x[5:-4]))  # Sắp xếp theo số thứ tự frame

    dct = DCT()
    all_hidden_texts = []  # Lưu tất cả thông điệp tìm thấy
    found_frame = None

    for file in files:
        frame_path = join(frames_dir, file)
        img = cv2.imread(frame_path, cv2.IMREAD_UNCHANGED)
        if img is None:
            print(f"Error: Could not read {frame_path}")
            continue
        hidden_text = dct.decode_image(img)
        if hidden_text:
            print(f"Scanning {file}: Hidden message found - {hidden_text}")
            all_hidden_texts.append((file, hidden_text))
            if found_frame is None:
                found_frame = file  # Ghi nhận frame đầu tiên có tin
        else:
            print(f"Scanning {file}: No hidden message found")

    if all_hidden_texts:
        print(f"Total frames with hidden messages: {len(all_hidden_texts)}")
        return all_hidden_texts[0][1], found_frame  # Trả về thông điệp và frame đầu tiên
    print("No hidden message found in any frame.")
    return None, None

def main_decode():
    frames_dir = "./frames/"
    if not os.path.exists(frames_dir):
        print("Error: Frames directory not found! Please run extract_frames.py first.")
        return

    # Quét và trích xuất thông điệp mã hóa
    hidden_text, frame_name = scan_frames_for_message(frames_dir)
    if not hidden_text:
        return

    # Lưu thông điệp mã hóa vào result.bin (chỉ lưu thông điệp đầu tiên)
    with open("result.bin", "wb") as f:
        f.write(hidden_text.encode('latin1'))
    print("Encrypted message extracted and saved to result.bin")

if __name__ == "__main__":
    main_decode()