#!/usr/bin/env python3
import sys
import os
from rc4_encryptor import rc4_decrypt_bytes

def brute_force_rc4(ciphertext_path, keylist_path):
    # Đọc thông điệp mã hóa từ file
    if not os.path.isfile(ciphertext_path):
        print(f"Error: Ciphertext file {ciphertext_path} not found!")
        return None, None

    try:
        with open(ciphertext_path, 'rb') as f:
            ciphertext_bytes = f.read()
        ciphertext = ciphertext_bytes.decode('latin1')  # Chuyển bytes thành chuỗi latin1
    except Exception as e:
        print(f"Error reading ciphertext file: {e}")
        return None, None

    # Đọc danh sách key
    if not os.path.isfile(keylist_path):
        print(f"Error: Key list file {keylist_path} not found!")
        return None, None

    try:
        with open(keylist_path, 'r', encoding='utf-8') as f:
            keys = [line.strip() for line in f if line.strip()]
    except Exception as e:
        print(f"Error reading key list file: {e}")
        return None, None

    # Brute force RC4 với log tiến độ
    total_keys = len(keys)
    print(f"Total keys to scan: {total_keys}")
    
    for idx, key in enumerate(keys, 1):
        print(f"Scanning key {idx}/{total_keys}: {key}")
        try:
            decrypted = rc4_decrypt_bytes(ciphertext_bytes, key).decode('utf-8')
            print(f"Success! Key: {key}")
            print(f"Decrypted message: {decrypted}")
            return decrypted, key
        except UnicodeDecodeError:
            print(f"Key {key}: Failed (Not UTF-8 text)")
        except Exception as e:
            print(f"Key {key}: Failed ({e})")
    
    print("Brute force failed: No valid key found.")
    return None, None

def main_brute_force():
    if len(sys.argv) != 3:
        print("Usage: python3 brute_force_rc4.py <ciphertext_file> <keylist_file>")
        print("Example: python3 brute_force_rc4.py result.bin keylist.txt")
        sys.exit(1)

    ciphertext_path = sys.argv[1]
    keylist_path = sys.argv[2]

    decrypted_msg, key_used = brute_force_rc4(ciphertext_path, keylist_path)

    if decrypted_msg:
        with open("final_result.txt", "w", encoding='utf-8') as f:
            f.write(decrypted_msg)
        print("Decryption successful! Decrypted message saved to final_result.txt")

if __name__ == "__main__":
    main_brute_force()