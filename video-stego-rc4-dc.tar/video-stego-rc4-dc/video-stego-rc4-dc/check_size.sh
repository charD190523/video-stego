#!/bin/bash

# Kiểm tra xem có đủ 2 đối số (file) không
if [ $# -ne 2 ]; then
    echo "Vui lòng nhập đúng 2 đường dẫn file."
    exit 1
fi

# Nhập file ban đầu và file sau khi giấu tin
file1="$1"  # File ban đầu
file2="$2"  # File sau khi giấu tin

# Kiểm tra xem file có tồn tại không
if [ ! -f "$file1" ]; then
    echo "File ban đầu không tồn tại: $file1"
    exit 1
fi

if [ ! -f "$file2" ]; then
    echo "File sau khi giấu tin không tồn tại: $file2"
    exit 1
fi

# Lấy kích thước của file1 và file2 (tính bằng byte)
size1=$(stat --format="%s" "$file1")
size2=$(stat --format="%s" "$file2")

# Kiểm tra chênh lệch dung lượng giữa file2 và file1
size_diff=$((size2 - size1))

# Đặt ngưỡng dung lượng chênh lệch tối đa (100 KB)
threshold=102400  # 100 KB = 102400 bytes

if [ "$size_diff" -le "$threshold" ]; then
    echo "Dung lượng file sau khi giấu tin là hợp lý (không vượt quá 100KB)."
else
    echo " Dung lượng file sau khi giấu tin lớn hơn file ban đầu quá nhiều, vượt quá 100KB."
fi

