# rc4_encryptor.py
import sys

# RC4 KSA
def KSA(key):
    key_length = len(key)
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % key_length]) % 256
        S[i], S[j] = S[j], S[i]
    return S

# RC4 PRGA
def PRGA(S, n):
    i = 0
    j = 0
    key = []
    while n > 0:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        K = S[(S[i] + S[j]) % 256]
        key.append(K)
        n -= 1
    return key

# RC4 encryption (returns bytes)
def rc4_encrypt_bytes(plaintext, key_str):
    key = [ord(c) for c in key_str]
    S = KSA(key)
    keystream = PRGA(S, len(plaintext))
    ciphertext = bytes([p ^ k for p, k in zip(plaintext, keystream)])
    return ciphertext

# RC4 encryption from str -> str (deprecated, kept for compatibility)
def rc4_encrypt(plaintext, key_str):
    return rc4_encrypt_bytes(plaintext.encode('utf-8'), key_str).decode('latin1')

# RC4 decryption from bytes -> bytes
def rc4_decrypt_bytes(ciphertext, key_str):
    key = [ord(c) for c in key_str]
    S = KSA(key)
    keystream = PRGA(S, len(ciphertext))
    plaintext = bytes([c ^ k for c, k in zip(ciphertext, keystream)])
    return plaintext

# RC4 decryption from str -> str (deprecated)
def rc4_decrypt(ciphertext, key_str):
    return rc4_decrypt_bytes(ciphertext.encode('latin1'), key_str).decode('utf-8')

# Run directly
if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1].endswith(".txt"):
        input_path = sys.argv[1]

        try:
            with open(input_path, 'r', encoding='utf-8') as f:
                message = f.read().strip()
        except Exception as e:
            print(f"Error reading file: {e}")
            sys.exit(1)

        key = input("Enter encryption key: ").strip()
        if not key:
            print("Key cannot be empty")
            sys.exit(1)

        encrypted = rc4_encrypt_bytes(message.encode('utf-8'), key)

        try:
            with open("encrypt_message.bin", 'wb') as out:
                out.write(encrypted)
            print("Encrypted message saved to encrypt_message.bin")
        except Exception as e:
            print(f"Error writing file: {e}")
            sys.exit(1)

    elif len(sys.argv) == 3 and sys.argv[1] == "--decrypt" and sys.argv[2].endswith(".bin"):
        input_path = sys.argv[2]

        try:
            with open(input_path, 'rb') as f:
                ciphertext = f.read()
        except Exception as e:
            print(f"Error reading encrypted file: {e}")
            sys.exit(1)

        key = input("Enter decryption key: ").strip()
        if not key:
            print("Key cannot be empty")
            sys.exit(1)

        try:
            decrypted = rc4_decrypt_bytes(ciphertext, key).decode('utf-8')
        except Exception as e:
            print(f"Decryption failed: {e}")
            sys.exit(1)

        try:
            with open("final_result.txt", 'w', encoding='utf-8') as f:
                f.write(decrypted)
            print("Decryption successful!")
            print("Decrypted message saved to final_result.txt")
        except Exception as e:
            print(f"Error writing final result: {e}")
            sys.exit(1)

    else:
        print("Usage:")
        print("  To encrypt:   python3 rc4_encryptor.py <message_file.txt>")
        print("  To decrypt:   python3 rc4_encryptor.py --decrypt <encrypted_file.bin>")
        sys.exit(1)
